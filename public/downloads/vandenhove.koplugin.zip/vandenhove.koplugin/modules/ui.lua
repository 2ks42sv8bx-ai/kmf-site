--[[
UI Module for vandenHove

Every message and dialog a reader sees, and the menu. Routine syncs say what
changed and clear on their own; errors say what failed and what the server said.
]]

local UIManager = require("ui/uimanager")
local InfoMessage = require("ui/widget/infomessage")
local InputDialog = require("ui/widget/inputdialog")
local Menu = require("ui/widget/menu")
local TextViewer = require("ui/widget/textviewer")
local Trapper = require("ui/trapper")
local PluginIdentity = require("modules/plugin_identity")
local Log = require("modules/log")
local log = Log.forModule("UI")
local _ = require("gettext")

local UI = {}

--- Show an informational message to the user
-- @param text string The message to display
-- @param timeout number|nil Auto-dismiss timeout in seconds (nil = no auto-dismiss)
-- @return table The widget now on screen, for a caller that may dismiss it early
function UI.showMessage(text, timeout)
	local message = InfoMessage:new({
		text = text,
		timeout = timeout,
	})
	UIManager:show(message)
	return message
end

--- Take a message this module put on screen back down
-- @param widget table|nil A widget an earlier show returned, nil to do nothing
function UI.dismiss(widget)
	if not widget then
		return
	end

	UIManager:close(widget)
end

--- Whether the reader is typing in a dialog
-- KOReader's note dialog keeps the highlight it edits and that highlight's index
-- until it closes, so an autosync that adds or removes highlights underneath it
-- can send the note, or a cancel, to the wrong place. Sleeping mid-note is enough
-- to set that off.
-- @return boolean True while an input dialog is open, under the screensaver too
function UI.isTyping()
	if not UIManager.getNthTopWidget then
		return false
	end

	local n = 1
	local widget = UIManager:getNthTopWidget(n)
	while widget do
		if widget._input_widget then
			return true
		end
		n = n + 1
		widget = UIManager:getNthTopWidget(n)
	end
	return false
end

--- Show a syncing in progress message
-- @return table The message widget, for a sync that ends before its timeout
function UI.showSyncingMessage()
	return UI.showMessage(_("Syncing…"), 2)
end

--- One line of the sync summary, in the singular when there is just one
-- @param count number How many highlights the line is about
-- @param one string The line for exactly one
-- @param many string The line for any other number, with a %d in it
-- @return string The line
local function countLine(count, one, many)
	if count == 1 then
		return one
	end

	return string.format(many, count)
end

--- Show the outcome of a sync: what changed, or that nothing did
-- @param result table `sent`, `removed`, `received` and `unplaced`
function UI.showSyncSuccess(result)
	local lines = {}

	local sent = result.sent or 0
	if sent > 0 then
		table.insert(lines, countLine(sent, _("Sent 1 highlight."), _("Sent %d highlights.")))
	end

	local removed = result.removed or 0
	if removed > 0 then
		table.insert(lines, countLine(removed, _("Removed 1 highlight."), _("Removed %d highlights.")))
	end

	local received = result.received or 0
	if received > 0 then
		table.insert(lines, countLine(received, _("Received 1 highlight."), _("Received %d highlights.")))
	end

	local unplaced = result.unplaced or 0
	if unplaced > 0 then
		table.insert(
			lines,
			countLine(
				unplaced,
				_("1 highlight wasn't found in this copy of the book."),
				_("%d highlights weren't found in this copy of the book.")
			)
		)
	end

	if #lines == 0 then
		table.insert(lines, _("Up to date."))
	end

	UI.showMessage(table.concat(lines, "\n"), 4)
end

--- Ask before a book's whole highlight set leaves the reader's devices
-- It blocks, which a ConfirmBox can only do inside a Trapper coroutine; without one
-- Trapper answers "OK" by itself, so an unwrapped caller is refused rather than
-- silently agreed with.
-- @param count number How many highlights would be removed
-- @return boolean True when the reader confirmed the removal
function UI.confirmRemoveAll(count)
	if not coroutine.running() then
		log.warn("Cannot ask about removing highlights outside a Trapper coroutine")
		return false
	end

	local confirmed = Trapper:confirm(
		string.format(_("Remove all %d highlights of this book from your devices?"), count),
		_("Keep"),
		_("Remove")
	)
	return confirmed == true
end

--- Show that a sync could not be completed
-- @param err any What went wrong, nil when there is nothing to name
function UI.showSyncFailed(err)
	local text = _("Couldn't sync.")
	if err ~= nil then
		text = text .. "\n" .. tostring(err)
	end

	UI.showMessage(text, 6)
end

--- Tell the reader this plugin is too old for the server
-- A plain message with nothing to answer: a sync can be running while the book or
-- the device is closing. It stays on screen long enough to read an address off it.
function UI.showUpgradeRequired()
	UI.showMessage(
		string.format(_("This version of %s is too old. Get the new one at:"), PluginIdentity.display_name)
			.. "\nhttps://vandenhove.page",
		10
	)
end

--- Show that signing in did not work
-- @param status number|nil The server's answer, nil when it could not be reached
function UI.showAuthError(status)
	local text = _("Couldn't sign in.")
	if status == nil then
		text = text .. "\n" .. _("Can't reach the server.")
	elseif status == 429 then
		text = text .. "\n" .. _("Try again later.")
	end
	UI.showMessage(text, 6)
end

--- Ask for the code that connects this device to an account
-- @param on_code function(code) Called with what the reader typed
-- @param on_new_code function|nil Offered once signed in: make a code for another device
function UI.askForCode(on_code, on_new_code)
	local dialog
	local buttons = {
		{
			{
				text = _("Cancel"),
				id = "close",
				callback = function()
					UIManager:close(dialog)
				end,
			},
			{
				text = _("Save"),
				is_enter_default = true,
				callback = function()
					local code = dialog:getInputText()
					UIManager:close(dialog)
					on_code(code)
				end,
			},
		},
	}
	if on_new_code then
		table.insert(buttons, {
			{
				text = _("Code for another device"),
				callback = function()
					UIManager:close(dialog)
					on_new_code()
				end,
			},
		})
	end
	dialog = InputDialog:new({
		title = PluginIdentity.display_name,
		input_hint = _("Code"),
		buttons = buttons,
	})

	UIManager:show(dialog)
	dialog:onShowKeyboard()
end

--- Show one group note, with a way to its place in the book
-- @param note table The note
-- @param on_go function(note) Called to go to the passage
local function showGroupNote(note, on_go)
	local viewer
	local body = note.quote
	if type(note.note) == "string" and note.note ~= "" then
		body = body .. "\n\n" .. note.note
	end
	viewer = TextViewer:new({
		title = string.format("%s, %s", note.name, note.group),
		text = body,
		buttons_table = {
			{
				{
					text = _("Go to passage"),
					callback = function()
						UIManager:close(viewer)
						on_go(note)
					end,
				},
				{
					text = _("Close"),
					callback = function()
						UIManager:close(viewer)
					end,
				},
			},
		},
	})
	UIManager:show(viewer)
end

--- List what the reader's groups share of this book
-- Shown here and only when asked for: never written into the reader's own highlights.
-- @param notes table The notes, in reading order
-- @param on_go function(note) Called to go to a passage
function UI.showGroupNotes(notes, on_go)
	if #notes == 0 then
		UI.showMessage(_("Nothing shared from this book yet."), 4)
		return
	end
	local list
	local items = {}
	for _idx, note in ipairs(notes) do
		table.insert(items, {
			text = note.name .. ": " .. note.quote,
			callback = function()
				showGroupNote(note, function(chosen)
					UIManager:close(list)
					on_go(chosen)
				end)
			end,
		})
	end
	list = Menu:new({
		title = _("Group notes"),
		item_table = items,
		is_popout = false,
		is_borderless = true,
		close_callback = function()
			UIManager:close(list)
		end,
	})
	UIManager:show(list)
end

--- Build the plugin's menu
-- @param handlers table Callback handlers for menu actions
--   - on_sync: function() Called when sync is triggered
--   - is_autosync_enabled: function() Returns autosync state
--   - on_toggle_autosync: function() Called when autosync is toggled
--   - on_group_notes: function() Called when the group's notes are asked for
--   - on_account: function() Called when the account dialog is asked for
-- @return table Menu item table for KOReader
function UI.buildMenuItems(handlers)
	return {
		-- The plugin's own name, not a translatable string: it is a proper noun.
		text = PluginIdentity.display_name,
		sorting_hint = "tools",
		sub_item_table = {
			{
				text = _("Sync this book"),
				callback = handlers.on_sync,
			},
			{
				text = _("Sync automatically"),
				checked_func = handlers.is_autosync_enabled,
				callback = handlers.on_toggle_autosync,
				keep_menu_open = true,
			},
			{
				text = _("Group notes"),
				callback = handlers.on_group_notes,
			},
			{
				text = _("Account"),
				keep_menu_open = true,
				callback = handlers.on_account,
			},
		},
	}
end

return UI
