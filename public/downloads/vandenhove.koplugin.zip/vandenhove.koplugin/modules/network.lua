--[[
Network Module for vandenHove Sync

One JSON request over HTTP or HTTPS, and the WiFi around it.
]]

local http = require("socket.http")
local https = require("ssl.https")
local ltn12 = require("ltn12")
local socketutil = require("socketutil")
local NetworkMgr = require("ui/network/manager")
local JSON = require("json")
local Log = require("modules/log")
local log = Log.forModule("Network")
local meta = require("_meta")

local Network = {}

-- How long a request may stall, and how long it may take start to finish.
-- KOReader leaves the total at -1 -- no limit at all -- so without these a server
-- that accepts a connection and then stops sending blocks the reader's screen for
-- as long as it likes. The file presets rather than the "large" ones: a request can
-- carry every note of a book, and aborting a slow but working sync is worse than
-- waiting a little longer for it.
Network.BLOCK_TIMEOUT = socketutil.FILE_BLOCK_TIMEOUT
Network.TOTAL_TIMEOUT = socketutil.FILE_TOTAL_TIMEOUT

-- Lets the server tell a plugin too old for it where to get a new one.
Network.CLIENT_VALUE = "koreader/" .. tostring(meta.version)

-- Track whether we enabled WiFi (so we can turn it off after sync)
local wifi_enabled_by_us = false

--- Make a JSON POST request
-- @param url string The URL to request
-- @param data table The data to JSON-encode and send
-- @param token string|nil Bearer token for authorization
-- @return number|nil HTTP status code
-- @return table|nil Parsed JSON response
-- @return string|nil Error message
function Network.postJson(url, data, token)
	local body = JSON.encode(data)
	local headers = {
		["Content-Type"] = "application/json",
		["Accept"] = "application/json",
		["Content-Length"] = tostring(#body),
		["X-Client"] = Network.CLIENT_VALUE,
	}
	if token then
		headers["Authorization"] = "Bearer " .. token
	end

	-- Before the sink is built, not after: `socketutil.table_sink` reads the total
	-- it has to honour at the moment it is created.
	socketutil:set_timeout(Network.BLOCK_TIMEOUT, Network.TOTAL_TIMEOUT)

	local response_body = {}
	local request = url:match("^https://") and https.request or http.request
	local result, code_or_err = request({
		url = url,
		method = "POST",
		headers = headers,
		source = ltn12.source.string(body),
		-- socketutil's sink rather than ltn12's: the total timeout is only enforced
		-- by the sink, so ltn12's would leave it decorative.
		sink = socketutil.table_sink(response_body),
	})

	socketutil:reset_timeout()

	-- LuaSocket answers `nil, message` for a request that never completed, and
	-- `1, status` for one that did. Told apart by the first value: the message
	-- travels where a status would, so testing the second alone would report a
	-- timeout as though it were an HTTP status.
	if not result then
		local err = tostring(code_or_err or "Unknown network error")
		log.dbg("Request failed:", err)
		return nil, nil, err
	end

	local text = table.concat(response_body)
	if text == "" then
		return code_or_err, nil, nil
	end

	local ok, decoded = pcall(JSON.decode, text)
	if not ok then
		return code_or_err, nil, "Invalid JSON response"
	end
	return code_or_err, decoded, nil
end

--- Run something once the device is online, turning WiFi on if it is off
-- @param fn function What to run once there is a connection
function Network.whenOnline(fn)
	if NetworkMgr:willRerunWhenOnline(fn) then
		-- Network is off; NetworkMgr runs `fn` once it is on.
		wifi_enabled_by_us = true
		return
	end

	wifi_enabled_by_us = false
	fn()
end

--- Disable WiFi if we enabled it for the sync
function Network.disableWifiIfNeeded()
	if wifi_enabled_by_us then
		NetworkMgr:turnOffWifi()
		wifi_enabled_by_us = false
	end
end

return Network
