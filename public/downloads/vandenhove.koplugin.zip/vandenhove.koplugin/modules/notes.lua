--[[
Notes Module for vandenHove Sync

The open book as the server sees it: what it holds, and how to change it. Changes
are made to the highlights in place and never by rebuilding them, because
KOReader's dialogs and caches hold on to the tables they were given.

A passage this copy can't show yet waits in `state.pending`: one the server sent
that hasn't been placed, or isn't in this copy at all. It counts as part of the
book's notes, or the next sync would read it as deleted here.

A page bookmark with a note is a passage too, named by the words its page opens with.
They are kept on the bookmark once read: a bookmark's position never moves, and a copy
of the book that spells them differently must go on calling it the same passage.
]]

local Event = require("ui/event")
local meta = require("_meta")
local Log = require("modules/log")
local log = Log.forModule("Notes")
local Place = require("modules/place")
local T = require("ffi/util").template
local _ = require("gettext")

local Notes = {}

-- A book opened for the first time on a new device can have many passages to
-- find. What doesn't fit in one sync simply waits for the next.
local PLACING_SECONDS = 5

local FALLBACK_DRAWER = "lighten"

local BOOKMARK_WORDS = 12

--- The words a position opens with, and where they end
-- @param document table The open document
-- @param start string The position
-- @return string|nil, string|nil The words and their end, or nil on a page with no text
local function openingWords(document, start)
	local stop = start
	for _ = 1, BOOKMARK_WORDS do
		local ok, following = pcall(document.getNextVisibleWordEnd, document, stop)
		if not ok or not following or following == stop then
			break
		end
		stop = following
	end
	if stop == start then
		return nil
	end
	local ok, text = pcall(document.getTextFromXPointers, document, start, stop)
	if not ok or type(text) ~= "string" or not text:find("%S") then
		return nil
	end
	return text:match("^%s*(.-)%s*$"), stop
end

--- The words naming an annotation, once it has any
-- @param item table The annotation
-- @return string|nil The words
local function quoteOf(item)
	if item.drawer then
		return item.text
	end
	return item.vandenhove_quote
end

--- What the book holds, in the order the server should read it
-- @param ui table The KOReader UI context
-- @param state table The book's sync state
-- @return table Array of notes
function Notes.read(ui, state)
	local notes = {}
	local pages = ui.document:getPageCount()

	for _, item in ipairs(ui.annotation.annotations) do
		if not item.drawer and item.note and not item.vandenhove_quote then
			item.vandenhove_quote, item.vandenhove_end = openingWords(ui.document, item.page)
		end
		local quote = quoteOf(item)
		if quote and quote ~= "" and (item.drawer or item.note) then
			table.insert(notes, {
				quote = quote,
				note = item.note,
				chapter = item.chapter,
				page = item.pageno,
				at = item.pageno and pages and pages > 0 and item.pageno / pages or nil,
				start = item.pos0 or item.page,
				["end"] = item.pos1 or item.vandenhove_end,
				made = item.datetime,
				mark = not item.drawer and "page" or nil,
				shared = item.vandenhove_shared,
			})
		end
	end
	for _, waiting in ipairs(state.pending) do
		table.insert(notes, {
			quote = waiting.quote,
			note = waiting.note,
			problem = waiting.problem,
			mark = waiting.mark,
			shared = waiting.shared,
		})
	end

	return notes
end

--- Change a highlight's note the way KOReader's own dialog does
-- @param ui table The KOReader UI context
-- @param item table The highlight
-- @param note string|nil The note, empty or nil for none
local function setNote(ui, item, note)
	local value = note ~= "" and note or nil
	if item.note == value then
		return
	end

	local had_note = item.note ~= nil
	item.note = value
	-- KOReader counts a highlight with a note differently, and a bookmark not at all.
	if had_note == (value ~= nil) or not item.drawer then
		ui.annotation:onAnnotationsModified({ item })
	elseif value then
		ui:handleEvent(Event:new("AnnotationsModified", { item, nb_highlights_added = -1, nb_notes_added = 1 }))
	else
		ui:handleEvent(Event:new("AnnotationsModified", { item, nb_highlights_added = 1, nb_notes_added = -1 }))
	end
end

--- Add a highlight the way KOReader's own selection does
-- @param ui table The KOReader UI context
-- @param waiting table The passage
-- @param start string Where it starts
-- @param stop string Where it ends
local function addHighlight(ui, waiting, start, stop)
	local defaults = (ui.view and ui.view.highlight) or {}
	local note = waiting.note ~= "" and waiting.note or nil
	local item = {
		page = start,
		pos0 = start,
		pos1 = stop,
		-- The server's spelling and not the book's, so this stays the same passage.
		text = waiting.quote,
		datetime = waiting.made,
		drawer = defaults.saved_drawer or FALLBACK_DRAWER,
		color = defaults.saved_color,
		note = note,
		vandenhove_shared = waiting.shared,
		chapter = ui.toc and ui.toc:getTocTitleByPage(start) or nil,
	}
	if ui.document.getEPubCFIRangeFromXPointers then
		item.epubcfi = ui.document:getEPubCFIRangeFromXPointers(start, stop)
	end
	local index = ui.annotation:addItem(item)
	local event = { item, index_modified = index }
	if note then
		event.nb_notes_added = 1
	else
		event.nb_highlights_added = 1
	end
	ui:handleEvent(Event:new("AnnotationsModified", event))
end

--- Add a page bookmark the way KOReader's own dogear does
-- @param ui table The KOReader UI context
-- @param waiting table The passage
-- @param start string Where it starts
-- @param stop string Where its words end
local function addBookmark(ui, waiting, start, stop)
	local chapter = ui.toc and ui.toc:getTocTitleByPage(start) or nil
	if chapter == "" then
		chapter = nil
	end
	local item = {
		page = start,
		text = chapter and T(_("in %1"), chapter) or nil,
		chapter = chapter,
		datetime = waiting.made,
		note = waiting.note ~= "" and waiting.note or nil,
		vandenhove_shared = waiting.shared,
		vandenhove_quote = waiting.quote,
		vandenhove_end = stop,
	}
	local index = ui.annotation:addItem(item)
	ui:handleEvent(Event:new("AnnotationsModified", { item, index_modified = index }))
end

local function removePending(state, quote)
	for i = #state.pending, 1, -1 do
		if state.pending[i].quote == quote then
			table.remove(state.pending, i)
		end
	end
end

local function pendingFor(state, quote)
	for _, waiting in ipairs(state.pending) do
		if waiting.quote == quote then
			return waiting
		end
	end
end

--- Do what the server answered
-- A passage is named exactly as this book spelled it when the book already holds it.
-- @param ui table The KOReader UI context
-- @param state table The book's sync state
-- @param changes table The server's list of changes
-- @return number How many highlights changed in the book
local function applyChanges(ui, state, changes)
	local annotations = ui.annotation.annotations
	local applied = 0

	for _, change in ipairs(changes) do
		local found = false
		for i = #annotations, 1, -1 do
			local item = annotations[i]
			if quoteOf(item) == change.quote then
				found = true
				applied = applied + 1
				if change.removed and item.drawer then
					ui.bookmark:removeItemByIndex(i)
				elseif change.removed then
					ui.bookmark:removeItem(item, i)
				else
					setNote(ui, item, change.note)
					item.vandenhove_shared = change.shared
				end
			end
		end

		local waiting = pendingFor(state, change.quote)
		if change.removed then
			removePending(state, change.quote)
		elseif waiting then
			waiting.note = change.note
			waiting.shared = change.shared
			if not change.problem then
				waiting.tried = nil
			end
			waiting.problem = change.problem
		elseif not found then
			table.insert(state.pending, {
				quote = change.quote,
				note = change.note,
				problem = change.problem,
				start = change.start,
				["end"] = change["end"],
				file = change.file,
				made = change.made,
				mark = change.mark,
				shared = change.shared,
			})
		end
	end

	return applied
end

--- Try to find the passages waiting to be placed
-- @param ui table The KOReader UI context
-- @param state table The book's sync state
-- @param file string|nil This copy's file id
-- @return number How many were placed
-- @return boolean Whether a placement failed in a way the server should hear about
local function placeWaiting(ui, state, file)
	local deadline = os.time() + PLACING_SECONDS
	local placed = 0
	local failed = false

	for i = #state.pending, 1, -1 do
		local waiting = state.pending[i]
		-- A new version may find what the last one couldn't.
		if waiting.tried ~= meta.version then
			if os.time() >= deadline then
				break
			end

			local started = os.clock()
			local start, stop, problem = Place.find(ui.document, waiting, file)
			log.info("Looked for a passage for", os.clock() - started, "seconds:", start and "found" or problem)
			if start then
				if waiting.mark == "page" then
					addBookmark(ui, waiting, start, stop)
				else
					addHighlight(ui, waiting, start, stop)
				end
				table.remove(state.pending, i)
				placed = placed + 1
			else
				waiting.tried = meta.version
				failed = failed or waiting.problem ~= problem
				waiting.problem = problem
			end
		end
	end

	if placed > 0 or failed then
		-- Searching selects text behind the scenes.
		ui.document:clearSelection()
	end
	return placed, failed
end

--- Share a highlight with the reader's groups, or stop
-- @param ui table The KOReader UI context
-- @param item table The highlight
function Notes.toggleShared(ui, item)
	item.vandenhove_shared = not item.vandenhove_shared or nil
	ui.annotation:onAnnotationsModified({ item })
end

--- Bring the book in line with what the server answered
-- @param ui table The KOReader UI context
-- @param state table The book's sync state
-- @param changes table The server's list of changes
-- @param file string|nil This copy's file id
-- @return table `received`, the highlights new to this book; `changed`, whether the
--   book changed at all; `report`, whether the server needs to hear what happened
function Notes.write(ui, state, changes, file)
	local applied = applyChanges(ui, state, changes)
	local placed, failed = placeWaiting(ui, state, file)
	return {
		received = placed,
		changed = applied > 0 or placed > 0,
		report = placed > 0 or failed,
	}
end

return Notes
