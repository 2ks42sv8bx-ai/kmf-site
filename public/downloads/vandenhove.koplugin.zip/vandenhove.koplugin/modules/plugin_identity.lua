--[[
Plugin Identity for vandenHove

Every string the plugin names itself with, derived from the one name in
`_meta.lua`: the settings key, the dispatcher action ids, the event names, the menu key and the label a reader sees.

The derivations are load-bearing: `spec/plugin_identity_spec.lua` pins each one
literally, because a changed string loses a reader's settings silently.
]]

local meta = require("_meta")

local PluginIdentity = {}

--- Derive the identity strings from a plugin name
-- Pure, so a spec can ask what any name would give without a second _meta.
-- @param name string The plugin's name, as `_meta.lua` spells it
-- @return table The display name, the namespace and the event prefix
function PluginIdentity.derive(name)
	-- Lowercase with whitespace as underscores: the shape of a settings key
	-- ("Two Words" -> "two_words").
	local namespace = name:lower():gsub("%s+", "_")
	-- Whitespace closed up, case kept: the shape of an event name, which is
	-- used by KOReader as `on<Event>` ("Two Words" -> "TwoWords").
	local event_prefix = name:gsub("%s+", "")

	return {
		display_name = name,
		namespace = namespace,
		event_prefix = event_prefix,
	}
end

-- This plugin's own identity, alongside the function. Copied field by field so
-- that adding a derivation above is the whole change.
for field, value in pairs(PluginIdentity.derive(meta.fullname)) do
	PluginIdentity[field] = value
end

return PluginIdentity
