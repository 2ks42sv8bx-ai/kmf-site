--[[
Place Module for vandenHove Sync

Finds a passage in the open book by its words. A position is only ever a local
cache of this: the book's own text is the address, which is what lets one note
work across copies and editions of a book.
]]

local Place = {}

-- KOReader's own default search: across inline formatting within one paragraph,
-- with spaces, apostrophes and hyphens folded. A KOReader too old to know these
-- ignores them and searches one stretch of markup at a time, and a Kobo-format book
-- gives every sentence its own.
local SEARCH_FLAGS = 0x00FF

-- What that search can't find whole, it can find by how it starts and how it ends,
-- with what lies between checked afterwards.
local ANCHOR_WORDS = 8
local ANCHOR_HITS = 8

-- A paragraph break; double quotes typed straight where the book has curly ones; the end
-- of a sentence in a Kobo-format book.
local SEARCH_STOPS = { "\n", '"\n', '.!?"\n' }

--- Reduce text to what a passage is, for comparing two spellings of it
-- @param text string The text
-- @return string Its letters and digits, without case, punctuation or spacing
function Place.fold(text)
	return (
		text
			:lower()
			:gsub("\194[\160\171\173\187]", "") -- no-break space, guillemets, soft hyphen
			:gsub("\226\128[\128-\191]", "") -- dashes, curly quotes and the like
			:gsub("[%s%p%c]", "")
	)
end

local function search(document, pattern, max_hits)
	local ok, hits = pcall(document.findAllText, document, pattern, true, 0, max_hits, false, SEARCH_FLAGS)
	return ok and hits or {}
end

local function matches(document, start, stop, folded)
	local ok, text = pcall(document.getTextFromXPointers, document, start, stop)
	return ok and type(text) == "string" and Place.fold(text) == folded
end

--- Whether a position another copy reported holds these words here
-- @param document table The open document
-- @param waiting table A passage with `start` and `end`
-- @return boolean True when the position can be used as it is
local function known(document, waiting)
	return document:isXPointerInDocument(waiting.start)
		and document:isXPointerInDocument(waiting["end"])
		and matches(document, waiting.start, waiting["end"], Place.fold(waiting.quote))
end

local function wordsOf(text)
	local words = {}
	for word in text:gmatch("%S+") do
		table.insert(words, word)
	end
	return words
end

--- Split a quote into the stretches a search can match as they are
-- @param quote string The quote
-- @param breaks string The characters a search can't get past
-- @return table Array of arrays of words
local function stretchesOf(quote, breaks)
	local stretches = {}
	for stretch in quote:gmatch("[^" .. breaks .. "]+") do
		local words = wordsOf(stretch)
		if #words > 0 then
			table.insert(stretches, words)
		end
	end
	return stretches
end

--- Find a quote by how its first stretch starts and its last one ends
-- @param document table The open document
-- @param quote string The quote
-- @param stretches table The quote's stretches
-- @return table Array of {start, end} of each place it is
local function byFirstAndLastWords(document, quote, stretches)
	local first, last = stretches[1], stretches[#stretches]
	-- A single short stretch was searched for already, and has nothing else to go on.
	if not first or (#stretches == 1 and #first < ANCHOR_WORDS * 2) then
		return {}
	end

	local head = table.concat(first, " ", 1, math.min(ANCHOR_WORDS, #first))
	local tail = table.concat(last, " ", math.max(1, #last - ANCHOR_WORDS + 1))
	local tails = search(document, tail, ANCHOR_HITS)
	local folded = Place.fold(quote)

	local found = {}
	for _, opening in ipairs(search(document, head, ANCHOR_HITS)) do
		for _, closing in ipairs(tails) do
			if
				document:compareXPointers(opening.start, closing["end"]) == 1
				and matches(document, opening.start, closing["end"], folded)
			then
				table.insert(found, { opening.start, closing["end"] })
			end
		end
	end
	return found
end

--- Find a passage in the open book
-- @param document table The open document
-- @param waiting table The passage: `quote`, and `start`, `end` and `file` if a
--   device has reported where it is
-- @param file string|nil This copy's file id; a reported position means nothing in
--   any other file
-- @return string|nil, string|nil Its start and end
-- @return string|nil "not_found" or "ambiguous" when there is no one place for it
function Place.find(document, waiting, file)
	if waiting.start and waiting["end"] and file and waiting.file == file and known(document, waiting) then
		return waiting.start, waiting["end"]
	end

	local hits = search(document, table.concat(wordsOf(waiting.quote), " "), 2)
	if #hits == 1 then
		return hits[1].start, hits[1]["end"]
	end
	if #hits > 1 then
		return nil, nil, "ambiguous"
	end

	-- What a search can't get past, from what always stops it to what only sometimes does.
	local found = {}
	for _, breaks in ipairs(SEARCH_STOPS) do
		found = byFirstAndLastWords(document, waiting.quote, stretchesOf(waiting.quote, breaks))
		if #found > 0 then
			break
		end
	end

	if #found == 0 then
		return nil, nil, "not_found"
	end
	if #found > 1 then
		return nil, nil, "ambiguous"
	end
	return found[1][1], found[1][2]
end

return Place
