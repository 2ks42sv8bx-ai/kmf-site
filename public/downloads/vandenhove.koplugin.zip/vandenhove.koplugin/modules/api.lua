--[[
Api Module for vandenHove Sync

The server, as the calls this device makes.
]]

local JSON = require("json")
local Network = require("modules/network")

local Api = {}
Api.__index = Api

-- KOReader's JSON encoder writes an empty Lua table as an object, and this is the
-- decoder's marker for writing it as an array.
local EMPTY_ARRAY = JSON.decode("[]") or {}

--- Create a new Api instance
-- @param settings Settings instance
-- @return Api instance
function Api:new(settings)
	return setmetatable({ settings = settings }, Api)
end

--- Swap a code for this device's token
-- @param code string The code the reader typed
-- @return string|nil The token
-- @return number|nil The HTTP status, nil when the server was not reached
function Api:pair(code)
	local status, reply = Network.postJson(self.settings:getApiUrl() .. "/pair", { code = code })
	if status == 200 and type(reply) == "table" and type(reply.token) == "string" then
		return reply.token, status
	end
	return nil, status
end

--- Sync one book
-- @param request table `book`, `base`, `notes` when anything changed here, `confirm`
-- @return number|nil HTTP status code
-- @return table|nil The server's answer
-- @return string|nil Error message
function Api:sync(request)
	if request.notes and #request.notes == 0 then
		request.notes = EMPTY_ARRAY
	end
	return Network.postJson(self.settings:getApiUrl() .. "/sync", request, self.settings:getToken())
end

--- Ask for a code for another device on this account
-- @return string|nil The code
-- @return number|nil The HTTP status
function Api:newCode()
	local status, reply = Network.postJson(self.settings:getApiUrl() .. "/codes", {}, self.settings:getToken())
	return status == 200 and type(reply) == "table" and reply.code or nil, status
end

--- Name the books this device has opened
-- @param books table `title`, `author` and `file` of each
-- @return number|nil The HTTP status
function Api:sendLibrary(books)
	local url = self.settings:getApiUrl() .. "/library"
	return (Network.postJson(url, { books = #books > 0 and books or EMPTY_ARRAY }, self.settings:getToken()))
end

--- Ask what other members of the reader's groups share of a book
-- @param book table The book
-- @return table|nil The notes
-- @return number|nil The HTTP status
function Api:groupNotes(book)
	local url = self.settings:getApiUrl() .. "/group-notes"
	local status, reply = Network.postJson(url, { book = book }, self.settings:getToken())
	return status == 200 and type(reply) == "table" and reply.notes or nil, status
end

return Api
