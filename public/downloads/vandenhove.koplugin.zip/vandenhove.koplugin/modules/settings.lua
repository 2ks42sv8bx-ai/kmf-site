--[[
Settings Module for vandenHove Sync

What this device remembers across books: the server, its token and whether to
sync by itself. Everything about a book is kept in the book's own sidecar.

Every setter persists. `G_reader_settings:saveSetting` writes an in-memory table,
and KOReader flushes that to disk on its own schedule.
]]

local PluginIdentity = require("modules/plugin_identity")

local Settings = {}
Settings.__index = Settings

local DEFAULT_BASE_URL = "https://sync.vandenhove.page"

local SETTINGS_KEY = PluginIdentity.namespace .. "_sync"

-- What an earlier version kept here, and no device should go on holding.
local RETIRED_KEYS = {
	"username",
	"password",
	"access_token",
	"refresh_token",
	"token_expires_at",
	"device_uuid",
}

--- Create a new Settings instance
-- @return Settings instance
function Settings:new()
	return setmetatable({}, Settings)
end

--- Load settings from KOReader's global settings
-- @return self for chaining
function Settings:load()
	local data = G_reader_settings:readSetting(SETTINGS_KEY)
	if data == nil then
		data = {}
		G_reader_settings:saveSetting(SETTINGS_KEY, data)
	end

	for _, key in ipairs(RETIRED_KEYS) do
		data[key] = nil
	end
	self._data = data
	return self
end

local function persist(self, key, value)
	self._data[key] = value
	G_reader_settings:saveSetting(SETTINGS_KEY, self._data)
end

--- Get the root of the server's API
-- @return string The URL, without a trailing slash
function Settings:getApiUrl()
	local base = self._data.base_url or DEFAULT_BASE_URL
	return (base:gsub("/+$", "")) .. "/v1"
end

--- Get this device's token
-- @return string|nil The token
function Settings:getToken()
	return self._data.token
end

--- Store this device's token
-- @param token string The token
function Settings:setToken(token)
	persist(self, "token", token)
end

--- Whether this device has an account to sync with
-- @return boolean True once a code has been swapped for a token
function Settings:isSignedIn()
	return self:getToken() ~= nil
end

--- Check if autosync is enabled
-- @return boolean True if autosync is enabled
function Settings:isAutosyncEnabled()
	return self._data.autosync_enabled == true
end

--- Toggle the autosync setting
-- @return boolean The new state
function Settings:toggleAutosync()
	local enabled = not self:isAutosyncEnabled()
	persist(self, "autosync_enabled", enabled)
	return enabled
end

return Settings
