--[[
Sync Module for vandenHove

One sync of the open book. The server decides everything: this says what the book
holds and does what comes back, so there is no merge here to keep in step with the
other clients, and a fix to the merge never has to reach anyone's e-reader.

All it remembers is the base: the state this book last agreed on with the server,
kept in the book's own sidecar, which KOReader writes in one go with the highlights
it describes. A book can't lose one without the other, so a lost sidecar reads as
knowing nothing and never as having deleted everything, and two copies of a book
can't be mistaken for each other.
]]

local Event = require("ui/event")
local UIManager = require("ui/uimanager")
local md5 = require("ffi/sha2").md5
local Log = require("modules/log")
local log = Log.forModule("Sync")
local Notes = require("modules/notes")
local PluginIdentity = require("modules/plugin_identity")

local Sync = {}
Sync.__index = Sync

local STATE_KEY = PluginIdentity.namespace .. "_sync"

-- At most: asked for notes, sent them, reported what was placed, confirmed a removal.
local MAX_ROUNDS = 5

--- Create a new Sync instance
-- @param api Api The server
-- @return Sync instance
function Sync:new(api)
	return setmetatable({ api = api }, Sync)
end

--- Say which book is open, the way the server asks
-- @param ui table The KOReader UI context
-- @return table `title`, `author` and `file`
function Sync.describeBook(ui)
	local props = ui.doc_props or {}
	return {
		title = props.display_title or props.title or ui.document.file:match("([^/]+)$"),
		author = props.authors,
		file = ui.doc_settings:readSetting("partial_md5_checksum"),
	}
end

--- Sum up a book's notes, to tell whether anything changed since the last sync
-- Spelled out field by field: the order `pairs` gives can differ between runs.
-- @param base string|nil The base the notes go with
-- @param notes table Array of notes
-- @return string The fingerprint
local function fingerprint(base, notes)
	local parts = { base or "" }
	for _, note in ipairs(notes) do
		table.insert(parts, note.quote)
		table.insert(parts, note.note or "")
		table.insert(parts, note.problem or "")
		table.insert(parts, note.shared and "shared" or "")
	end
	return md5(table.concat(parts, "\0"))
end

--- Sync the open book
-- @param ui table The KOReader UI context
-- @param opts table|nil `confirm_removal` function(count) -> boolean, asked before
--   every highlight of a book leaves the reader's devices. Absent means nobody can
--   be asked, and the book waits for a sync that can.
-- @return table The outcome: `sent`, `removed`, `received`, `unplaced`, or `error`
--   with the HTTP `code` when the server refused
function Sync:run(ui, opts)
	local state = ui.doc_settings:readSetting(STATE_KEY) or {}
	state.pending = state.pending or {}

	local book = Sync.describeBook(ui)
	local result = { sent = 0, removed = 0, received = 0 }
	local confirmed = false
	local must_send = false

	for _ = 1, MAX_ROUNDS do
		local notes = Notes.read(ui, state)
		local changed_here = fingerprint(state.base, notes) ~= state.fingerprint

		local code, reply, err = self.api:sync({
			book = book,
			base = state.base,
			notes = (must_send or changed_here) and notes or nil,
			-- A reader deletes highlights one at a time. Only all of them going at
			-- once is worth a question.
			confirm = confirmed or #notes > 0,
		})

		if code ~= 200 or type(reply) ~= "table" then
			result.code = code
			result.error = err or (type(reply) == "table" and reply.error) or tostring(code)
			return result
		end

		if reply.send then
			must_send = true
		elseif reply.confirm then
			if not (opts and opts.confirm_removal and opts.confirm_removal(reply.confirm)) then
				log.info("Keeping", reply.confirm, "highlights the book no longer holds")
				return result
			end
			confirmed = true
			must_send = true
		else
			result.sent = result.sent + (tonumber(reply.sent) or 0)
			result.removed = result.removed + (tonumber(reply.removed) or 0)

			local outcome = Notes.write(ui, state, reply.changes or {}, book.file)
			result.received = result.received + outcome.received
			result.unplaced = #state.pending

			local base = type(reply.base) == "string" and reply.base or nil
			local summed = not outcome.report and fingerprint(base, Notes.read(ui, state)) or nil
			if outcome.changed or outcome.report or base ~= state.base or summed ~= state.fingerprint then
				state.base = base
				state.fingerprint = summed
				ui.doc_settings:saveSetting(STATE_KEY, state)
				ui:handleEvent(Event:new("FlushSettings"))
			end

			if outcome.changed then
				if ui.view and ui.view.footer then
					ui.view.footer:maybeUpdateFooter()
				end
				UIManager:setDirty(ui.dialog, "ui")
			end

			if not outcome.report then
				return result
			end
			must_send = true
		end
	end

	log.warn("The server kept asking for more")
	return result
end

return Sync
