local _ = require("gettext")
return {
	-- KOReader names a plugin after its folder, and warns about a name here.
	fullname = "vandenHove",
	description = _([[Your highlights and notes, in Obsidian and back.]]),
	-- Sent with every request, so the server can tell a plugin too old for it.
	version = "1.2.0",
	homepage = "https://vandenhove.page",
}
