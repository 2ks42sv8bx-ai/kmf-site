--[[
vandenHove for KOReader

Keeps a book's highlights and notes in step with the vandenHove server, and
through it with Obsidian. Syncs on request, or by itself on suspend and exit.
]]

local WidgetContainer = require("ui/widget/container/widgetcontainer")
local ButtonDialog = require("ui/widget/buttondialog")
local TextViewer = require("ui/widget/textviewer")
local UIManager = require("ui/uimanager")
local Dispatcher = require("dispatcher")
local Trapper = require("ui/trapper")
local T = require("ffi/util").template
local _ = require("gettext")

local Log = require("modules/log")
local log = Log.forModule("Main")
local PluginIdentity = require("modules/plugin_identity")
local Settings = require("modules/settings")
local Network = require("modules/network")
local Notes = require("modules/notes")
local Place = require("modules/place")
local Api = require("modules/api")
local Sync = require("modules/sync")
local UI = require("modules/ui")

-- The plugin's own names for the things KOReader keys by: the menu entry, the
-- gesture-bindable action and the event it dispatches.
local MENU_KEY = PluginIdentity.namespace .. "_sync"
local ACTION_SYNC = PluginIdentity.namespace .. "_sync_current_book"
local EVENT_SYNC = PluginIdentity.event_prefix .. "SyncCurrentBook"

local VandenHoveSync = WidgetContainer:extend({
	name = PluginIdentity.display_name,
	is_doc_only = true, -- Only show when document is open
})

--- Register the gesture-bindable action with KOReader's Dispatcher
function VandenHoveSync:onDispatcherRegisterActions()
	Dispatcher:registerAction(ACTION_SYNC, {
		category = "none",
		event = EVENT_SYNC,
		title = T(_("Sync this book with %1"), PluginIdentity.display_name),
		reader = true,
	})
end

--- Put the menu first in Tools
-- KOReader appends plugin entries after all of its own, which is the second page
-- of Tools. The order table outlives the book, so this guards against inserting
-- again each time one is opened.
function VandenHoveSync:placeFirstInTools()
	local ok, order = pcall(require, "ui/elements/reader_menu_order")
	if not ok or type(order) ~= "table" or type(order.tools) ~= "table" then
		return
	end

	for _idx, key in ipairs(order.tools) do
		if key == MENU_KEY then
			return
		end
	end

	table.insert(order.tools, 1, MENU_KEY)
end

--- Initialize the plugin
-- Fixed-layout documents stay out of it: a passage is placed by searching for its
-- words, which needs reflowable text. The gesture action is registered regardless,
-- because it is global configuration.
function VandenHoveSync:init()
	self:onDispatcherRegisterActions()

	self.is_supported_document = self.ui.rolling ~= nil
	if not self.is_supported_document then
		return
	end

	self.settings = Settings:new():load()
	self.api = Api:new(self.settings)
	self.sync = Sync:new(self.api)

	self:placeFirstInTools()
	self.ui.menu:registerToMainMenu(self)
	self:addShareButton()
end

--- Put Share one tap away, wherever a highlight is
-- KOReader offers no way to add to these two dialogs, so the row goes in as each is
-- built. If a KOReader names them differently, they simply stay as they were.
function VandenHoveSync:addShareButton()
	local highlight = self.ui.highlight

	local function shareRow(item, close)
		return {
			{
				text = item.vandenhove_shared and _("Unshare with groups") or _("Share with groups"),
				callback = function()
					close()
					Notes.toggleShared(self.ui, item)
					UI.showMessage(item.vandenhove_shared and _("Shared.") or _("No longer shared."), 2)
				end,
			},
		}
	end

	local function addRowWhileBuilding(method, widget_class, rows_field)
		local build = highlight[method]
		if not build then
			return
		end
		highlight[method] = function(this, index, ...)
			local item = this.ui.annotation.annotations[index]
			local own_new = rawget(widget_class, "new")
			local widget
			widget_class.new = function(class, opts)
				if item and opts and opts[rows_field] then
					table.insert(
						opts[rows_field],
						1,
						shareRow(item, function()
							UIManager:close(widget)
						end)
					)
				end
				widget_class.new = own_new
				widget = class.new(class, opts)
				return widget
			end
			local ok, err = pcall(build, this, index, ...)
			widget_class.new = own_new
			if not ok then
				error(err)
			end
		end
	end

	-- Tapping a highlight opens this one, or the note first if it has a note.
	addRowWhileBuilding("showHighlightDialog", ButtonDialog, "buttons")
	addRowWhileBuilding("showHighlightNoteOrDialog", TextViewer, "buttons_table")

	-- Selecting new text: highlight and share in one tap.
	highlight:addToHighlightDialog("02_vandenhove_share", function(this, index)
		return {
			text = _("Highlight and share"),
			enabled = this.hold_pos ~= nil,
			show_in_highlight_dialog_func = function()
				return index == nil
			end,
			callback = function()
				local saved = this:saveHighlight(true)
				this:onClose()
				local item = saved and this.ui.annotation.annotations[saved]
				if item then
					Notes.toggleShared(this.ui, item)
					UI.showMessage(_("Shared."), 2)
				end
			end,
		}
	end)
end

--- Add plugin menu items to KOReader main menu
function VandenHoveSync:addToMainMenu(menu_items)
	menu_items[MENU_KEY] = UI.buildMenuItems({
		on_sync = function()
			self:syncCurrentBook()
		end,
		is_autosync_enabled = function()
			return self.settings:isAutosyncEnabled()
		end,
		on_toggle_autosync = function()
			self.settings:toggleAutosync()
		end,
		on_group_notes = function()
			self:showGroupNotes()
		end,
		on_account = function()
			self:signIn()
		end,
	})
end

--- Ask for a code and swap it for this device's token
-- @param after function|nil What to do once signed in
function VandenHoveSync:signIn(after)
	local new_code = self.settings:isSignedIn() and function()
		self:showNewCode()
	end or nil
	UI.askForCode(function(code)
		Network.whenOnline(function()
			local token, status = self.api:pair(code)
			Network.disableWifiIfNeeded()
			if not token then
				UI.showAuthError(status)
				return
			end
			self.settings:setToken(token)
			if after then
				after()
			end
		end)
	end, new_code)
end

--- Make a code for another device, for a reader who set this one up first
function VandenHoveSync:showNewCode()
	Network.whenOnline(function()
		local code, status = self.api:newCode()
		Network.disableWifiIfNeeded()
		if code then
			UI.showMessage(code)
		else
			UI.showAuthError(status)
		end
	end)
end

--- Show what the reader's groups share of the open book
function VandenHoveSync:showGroupNotes()
	if not self.settings:isSignedIn() then
		self:signIn(function()
			self:showGroupNotes()
		end)
		return
	end
	Network.whenOnline(function()
		local notes, status = self.api:groupNotes(Sync.describeBook(self.ui))
		Network.disableWifiIfNeeded()
		if not notes then
			UI.showSyncFailed(status)
			return
		end
		UI.showGroupNotes(notes, function(note)
			self:goToPassage(note)
		end)
	end)
end

--- Go to a group note's passage, found in this copy by its words
-- @param note table The note
function VandenHoveSync:goToPassage(note)
	local start = Place.find(self.ui.document, { quote = note.quote })
	self.ui.document:clearSelection()
	if not start then
		UI.showMessage(_("That passage wasn't found in this copy of the book."), 4)
		return
	end
	self.ui.link:addCurrentLocationToStack()
	self.ui.rolling:onGotoXPointer(start, start)
end

--- Sync the currently open book
-- Without an account a manual sync asks for one and carries on afterwards; an
-- autosync has nobody to ask.
-- @param is_autosync boolean If true, run in silent mode (no UI feedback)
function VandenHoveSync:syncCurrentBook(is_autosync)
	if not self.is_supported_document then
		return
	end

	if not self.settings:isSignedIn() then
		if not is_autosync then
			self:signIn(function()
				self:syncCurrentBook()
			end)
		end
		return
	end

	Network.whenOnline(function()
		self:_runSync(is_autosync)
	end)
end

--- Run one sync from start to finish, including what has to follow it
-- @param is_autosync boolean If true, run in silent mode
function VandenHoveSync:_runSync(is_autosync)
	if not self.ui.document then
		log.warn("Cannot sync - no document available")
		return
	end

	-- Checked here rather than on suspend: with WiFi off this runs once the device
	-- has connected, by which time the reader may well be typing.
	if is_autosync and UI.isTyping() then
		log.info("Skipping the autosync while the reader is typing")
		Network.disableWifiIfNeeded()
		return
	end

	local sync = function()
		if not is_autosync then
			self.syncing_message = UI.showSyncingMessage()
		end

		local success, err = pcall(function()
			self:doSync(is_autosync)
		end)
		self.syncing_message = nil

		if not success then
			log.err("Error in sync:", err)
			if not is_autosync then
				UI.showSyncFailed(err)
			end
		end

		Network.disableWifiIfNeeded()
	end

	if is_autosync then
		-- An autosync runs while the book is being torn down and has nobody to
		-- put a question to, so it stays a plain call that never blocks.
		sync()
		return
	end

	-- A manual sync may have to ask before withdrawing highlights from the reader's
	-- other devices, and a ConfirmBox can only block inside a Trapper coroutine.
	Trapper:wrap(sync)
end

--- Execute the sync and report how it went
-- @param is_autosync boolean If true, run in silent mode
function VandenHoveSync:doSync(is_autosync)
	local result = self.sync:run(self.ui, {
		-- Only a manual sync has a reader in front of it to answer.
		confirm_removal = (not is_autosync) and UI.confirmRemoveAll or nil,
	})

	-- An autosync says this one too: a plugin that has quietly stopped working is
	-- exactly what a reader needs told about.
	if result.code == 426 then
		UI.dismiss(self.syncing_message)
		UI.showUpgradeRequired()
		return
	end

	if is_autosync then
		if result.error then
			log.warn("Autosync failed:", result.error)
		end
		return
	end

	if result.code == 401 then
		UI.showAuthError(result.code)
	elseif result.error then
		UI.showSyncFailed(result.error)
	else
		UI.showSyncSuccess(result)
	end
end

--- Handle the "sync this book" gesture action
-- KOReader dispatches an event by calling the method named "on" .. event, so this
-- is assigned under the derived name.
VandenHoveSync["on" .. EVENT_SYNC] = function(self)
	self:syncCurrentBook()
	return true
end

--- Called when device goes to sleep/suspend
function VandenHoveSync:onSuspend()
	if self.is_supported_document and self.settings:isAutosyncEnabled() then
		self:syncCurrentBook(true)
	end
	return false
end

--- Called when KOReader exits
function VandenHoveSync:onExit()
	if self.is_supported_document and self.settings:isAutosyncEnabled() then
		self:syncCurrentBook(true)
	end
	return false
end

return VandenHoveSync
