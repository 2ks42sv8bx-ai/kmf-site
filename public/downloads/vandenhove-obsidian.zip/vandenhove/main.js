"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => VandenHovePlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");

// src/api.ts
var ApiError = class extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
    this.name = "ApiError";
  }
  status;
};
var NotLoggedInError = class extends Error {
  constructor() {
    super("This device isn't connected any more");
    this.name = "NotLoggedInError";
  }
};
var DEFAULT_SERVER = "https://sync.vandenhove.page";
var CLIENT = "obsidian/1.1.0";
var ServerApi = class {
  constructor(serverUrl, http, tokens) {
    this.http = http;
    this.tokens = tokens;
    this.base = `${(serverUrl || DEFAULT_SERVER).replace(/\/+$/, "")}/v1`;
  }
  http;
  tokens;
  base;
  isLoggedIn() {
    return this.tokens.get() !== null;
  }
  logout() {
    this.tokens.set(null);
  }
  async call(method, path, body) {
    const token = this.tokens.get();
    const response = await this.http({
      url: `${this.base}${path}`,
      method,
      headers: {
        "X-Client": CLIENT,
        ...token ? { Authorization: `Bearer ${token}` } : {},
        ...body === void 0 ? {} : { "Content-Type": "application/json" }
      },
      ...body === void 0 ? {} : { body: JSON.stringify(body) }
    });
    if (response.status === 401) {
      this.logout();
      throw new NotLoggedInError();
    }
    if (response.status === 426) {
      throw new ApiError("This version of vandenHove is too old. Get the new one at vandenhove.page", 426);
    }
    if (response.status < 200 || response.status >= 300) {
      throw new ApiError(`${method} ${path} failed (${response.status})`, response.status);
    }
    return response.json;
  }
  /** Swap a code for this device's token. */
  async pair(code) {
    const response = await this.http({
      url: `${this.base}/pair`,
      method: "POST",
      headers: { "X-Client": CLIENT, "Content-Type": "application/json" },
      body: JSON.stringify({ code })
    });
    if (response.status === 401) throw new ApiError("That code doesn't work", 401);
    if (response.status === 429) throw new ApiError("Too many tries. Try again later", 429);
    if (response.status !== 200) throw new ApiError(`Couldn't connect (${response.status})`, response.status);
    this.tokens.set(response.json.token);
  }
  /** A code for another device on this account. */
  async newCode() {
    return (await this.call("POST", "/codes")).code;
  }
  async groupNotes(book) {
    return (await this.call("POST", "/group-notes", { book })).notes;
  }
  async listBooks() {
    return (await this.call("GET", "/books")).books;
  }
  async sync(request) {
    return await this.call("POST", "/sync", request);
  }
};

// src/format.ts
var REMOVED_SECTION = "Removed on Kobo";
var NO_CHAPTER_SECTION = "Highlights";
var PROBLEM_PREFIX = "vandenHove: ";
var PROBLEMS = {
  not_found: "this quote is not in the book, word for word; edit it to try again",
  ambiguous: "this quote occurs more than once in the book; quote more words",
  no_quote: "this callout has no quote"
};
var HIGHLIGHT_START = /^>\s*\[!quote\][+-]?(.*)$/i;
var CALLOUT_LINE = /^>/;
var ID_LINE = /^\^vdh-([\w-]+)\s*$/;
var SECTION_HEADING = /^(#{1,2})\s+(.*?)\s*#*\s*$/;
var FENCE = /^(`{3,}|~{3,})/;
var PROBLEM = /^>\s*\[!warning\]\s*vandenHove:\s*(.*)$/i;
var PAGE = /\bp\.\s*(\d+)/;
var SHARED_TITLE = /\s*·\s*shared\s*$/i;
var RESERVED = /^\\*(#{1,2}\s|>\s*\[!quote\]|>\s*\[!warning\]\s*vandenHove:|\^vdh-[\w-]+\s*$)/i;
function normalizeNote(note) {
  return (note ?? "").replace(/\r\n/g, "\n").trim();
}
function normalizeQuote(quote) {
  return quote.split(/\s+/).filter(Boolean).join(" ");
}
function hashText(text) {
  let h1 = 3735928559;
  let h2 = 1103547991;
  for (let i = 0; i < text.length; i++) {
    const ch = text.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507) ^ Math.imul(h2 ^ h2 >>> 13, 3266489909);
  h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507) ^ Math.imul(h1 ^ h1 >>> 13, 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}
function isHeading(line) {
  return line.match(SECTION_HEADING);
}
function isBlank(line) {
  return line === void 0 || line.trim() === "";
}
function unescapeLine(line) {
  return line.startsWith("\\") && (RESERVED.test(line) || /^\\+(`{3,}|~{3,})/.test(line)) ? line.slice(1) : line;
}
function escapeNote(note) {
  const lines = note === "" ? [] : note.split("\n");
  const fences = lines.filter((line) => FENCE.test(line)).length;
  return lines.map((line) => {
    if (RESERVED.test(line) || /^\\+(`{3,}|~{3,})/.test(line)) return `\\${line}`;
    return fences % 2 === 1 && FENCE.test(line) ? `\\${line}` : line;
  });
}
function trimBlankLines(lines) {
  let start = 0;
  let end = lines.length;
  while (start < end && isBlank(lines[start])) start++;
  while (end > start && isBlank(lines[end - 1])) end--;
  return lines.slice(start, end);
}
function calloutBody(lines) {
  return lines.map((line) => line.replace(/^>\s?/, ""));
}
function problemCode(message) {
  const known = Object.entries(PROBLEMS).find(([, text]) => text === message.trim());
  return known ? known[0] : null;
}
function parseBlock(lines, start, section) {
  const title = lines[start].match(HIGHLIGHT_START)?.[1]?.trim() ?? "";
  let cursor = start + 1;
  const quoteLines = [];
  while (cursor < lines.length && CALLOUT_LINE.test(lines[cursor])) {
    quoteLines.push(lines[cursor]);
    cursor++;
  }
  let blockId = null;
  let afterBlanks = cursor;
  while (afterBlanks < lines.length && isBlank(lines[afterBlanks])) afterBlanks++;
  const idMatch = lines[afterBlanks]?.match(ID_LINE);
  if (idMatch) {
    blockId = idMatch[1];
    cursor = afterBlanks + 1;
  }
  const noteLines = [];
  let problem = null;
  let inFence = false;
  while (cursor < lines.length) {
    const line = lines[cursor];
    if (HIGHLIGHT_START.test(line)) break;
    if (FENCE.test(line)) inFence = !inFence;
    if (!inFence && isHeading(line)) break;
    const problemMatch = inFence ? null : line.match(PROBLEM);
    if (problemMatch) {
      problem = problemCode(problemMatch[1] ?? "");
      cursor++;
      continue;
    }
    noteLines.push(unescapeLine(line));
    cursor++;
  }
  const block = {
    blockId,
    title,
    quote: calloutBody(quoteLines).join("\n").trim(),
    note: trimBlankLines(noteLines).join("\n"),
    problem,
    section,
    page: Number(title.match(PAGE)?.[1]) || null,
    shared: SHARED_TITLE.test(title)
  };
  return [block, cursor];
}
function frontmatterValue(front, key) {
  const value = front.match(new RegExp(`^${key}:[ \\t]*(.*?)[ \\t]*$`, "m"))?.[1];
  if (!value) return null;
  if (value.startsWith('"')) {
    try {
      return JSON.parse(value);
    } catch {
      return value;
    }
  }
  return value.replace(/^'(.*)'$/, "$1");
}
function parseNote(text) {
  const lines = text.replace(/\r\n/g, "\n").split("\n");
  const segments = [];
  let free = { kind: "free", lines: [], heading: null };
  let section = null;
  let cursor = 0;
  let inFence = false;
  if (lines[0] === "---") {
    const close = lines.indexOf("---", 1);
    if (close !== -1) {
      free.lines.push(...lines.slice(0, close + 1));
      cursor = close + 1;
    }
  }
  const front = free.lines.join("\n");
  while (cursor < lines.length) {
    const line = lines[cursor];
    if (HIGHLIGHT_START.test(line)) {
      const [block, next] = parseBlock(lines, cursor, section);
      if (free.lines.length > 0 || free.heading !== null) segments.push(free);
      segments.push({ kind: "block", lines: lines.slice(cursor, next), block });
      free = { kind: "free", lines: [], heading: null };
      cursor = next;
      inFence = false;
      continue;
    }
    if (FENCE.test(line)) inFence = !inFence;
    const heading = inFence ? null : isHeading(line);
    if (heading) {
      if (free.lines.length > 0) segments.push(free);
      section = heading[2] ?? "";
      free = { kind: "free", lines: [], heading: section };
    }
    free.lines.push(line);
    cursor++;
  }
  segments.push(free);
  return {
    bookId: frontmatterValue(front, "vdh_book_id"),
    base: frontmatterValue(front, "vdh_base"),
    title: frontmatterValue(front, "title"),
    author: frontmatterValue(front, "author"),
    blocks: segments.flatMap((segment) => segment.kind === "block" ? [segment.block] : []),
    segments
  };
}
function notesOf(note) {
  return note.blocks.filter((block) => block.section !== REMOVED_SECTION && normalizeQuote(block.quote) !== "").map((block) => ({
    quote: block.quote,
    note: block.note,
    ...block.problem ? { problem: block.problem } : {},
    ...block.shared ? { shared: true } : {}
  }));
}
function titleLine(title) {
  return `> [!quote]${title ? ` ${title}` : ""}`;
}
function sharedTitle(title, shared) {
  const plain = title.replace(SHARED_TITLE, "");
  if (!shared) return plain;
  return plain ? `${plain} \xB7 shared` : "\xB7 shared";
}
function toggleShared(text, line) {
  let start = 0;
  for (const segment of parseNote(text).segments) {
    if (segment.kind === "block" && line >= start && line < start + segment.lines.length) {
      const { block } = segment;
      if (block.section === REMOVED_SECTION) return null;
      return { line: start, text: titleLine(sharedTitle(block.title, !block.shared)) };
    }
    start += segment.lines.length;
  }
  return null;
}
function renderBlock(block) {
  const out = [titleLine(block.title)];
  for (const line of block.quote.split("\n")) out.push(line === "" ? ">" : `> ${line}`);
  out.push("");
  if (block.blockId !== null) out.push(`^vdh-${block.blockId}`, "");
  const note = escapeNote(block.note);
  if (note.length > 0) out.push(...note, "");
  if (block.problem !== null) {
    out.push(`> [!warning] ${PROBLEM_PREFIX}${PROBLEMS[block.problem] ?? block.problem}`, "");
  }
  return out;
}
function titleOf(page, mark) {
  const where = page === null ? "" : `p. ${page}`;
  if (mark !== "page") return where;
  return where === "" ? "Bookmark" : `Bookmark, ${where}`;
}
function newBlockId(quote) {
  return hashText(normalizeQuote(quote));
}
function blocksWith(note, quote) {
  return note.segments.filter(
    (segment) => segment.kind === "block" && segment.block.quote === quote
  );
}
function activeBlocks(note, quote) {
  return blocksWith(note, quote).filter((segment) => segment.block.section !== REMOVED_SECTION);
}
function headingIndex(note, name) {
  return note.segments.findIndex((s) => s.kind === "free" && s.heading === name);
}
function sectionEnd(note, headingAt) {
  for (let i = headingAt + 1; i < note.segments.length; i++) {
    const segment = note.segments[i];
    if (segment.kind === "free" && segment.heading !== null) return i;
  }
  return note.segments.length;
}
function ensureBlankBefore(note, index) {
  for (let i = index - 1; i >= 0; i--) {
    const segment = note.segments[i];
    if (segment.lines.length === 0) continue;
    if (!isBlank(segment.lines[segment.lines.length - 1])) segment.lines.push("");
    return;
  }
}
function ensureSection(note, name, laterChapters) {
  const existing = headingIndex(note, name);
  if (existing !== -1) return existing;
  const anchors = [...laterChapters, REMOVED_SECTION].map((later) => headingIndex(note, later));
  const at = anchors.find((index2) => index2 !== -1) ?? note.segments.length;
  dropTrailingEmptySegment(note, at);
  const index = Math.min(at, note.segments.length);
  ensureBlankBefore(note, index);
  const segment = { kind: "free", lines: [`## ${name}`, ""], heading: name };
  note.segments.splice(index, 0, segment);
  return index;
}
function dropTrailingEmptySegment(note, at) {
  const last = note.segments[note.segments.length - 1];
  if (at >= note.segments.length - 1 && last?.kind === "free" && last.heading === null && last.lines.every((line) => line === "")) {
    note.segments.pop();
  }
}
function insertIntoSection(note, block, section, laterChapters) {
  const headingAt = ensureSection(note, section, laterChapters);
  const end = sectionEnd(note, headingAt);
  let at = end;
  if (block.page !== null) {
    for (let i = headingAt + 1; i < end; i++) {
      const segment = note.segments[i];
      if (segment.kind === "block" && segment.block.page !== null && segment.block.page > block.page) {
        at = i;
        break;
      }
    }
  }
  dropTrailingEmptySegment(note, at);
  at = Math.min(at, note.segments.length);
  ensureBlankBefore(note, at);
  note.segments.splice(at, 0, { kind: "block", lines: renderBlock(block), block });
}
function dropEmptyRemovedSection(note) {
  const at = headingIndex(note, REMOVED_SECTION);
  if (at === -1) return;
  const end = sectionEnd(note, at);
  const empty = note.segments.slice(at, end).every((s) => s.kind === "free" && s.lines.every((line, i) => isBlank(line) || i === 0 && s.heading !== null));
  if (empty) note.segments.splice(at, end - at);
}
function keptAndNew(kept, incoming) {
  const paragraphs = [kept, incoming].flatMap((note) => normalizeNote(note).split(/\n\s*\n/));
  return [...new Set(paragraphs)].filter((paragraph) => paragraph !== "").join("\n\n");
}
function rerender(segment) {
  segment.lines = renderBlock(segment.block);
}
function applyEdit(note, edit) {
  switch (edit.type) {
    case "setNote": {
      let applied = true;
      for (const segment of activeBlocks(note, edit.quote)) {
        if (normalizeNote(segment.block.note) !== normalizeNote(edit.expect)) {
          applied = false;
          continue;
        }
        segment.block.note = normalizeNote(edit.note);
        segment.block.problem = edit.problem;
        segment.block.shared = edit.shared;
        segment.block.title = sharedTitle(segment.block.title, edit.shared);
        rerender(segment);
      }
      return applied;
    }
    case "moveToRemoved": {
      let applied = true;
      for (const segment of activeBlocks(note, edit.quote)) {
        if (normalizeNote(segment.block.note) !== normalizeNote(edit.expect)) {
          applied = false;
          continue;
        }
        note.segments.splice(note.segments.indexOf(segment), 1);
        segment.block.section = REMOVED_SECTION;
        insertIntoSection(note, segment.block, REMOVED_SECTION, []);
      }
      return applied;
    }
    case "add": {
      const { highlight } = edit;
      if (activeBlocks(note, highlight.quote).length > 0) return false;
      const removed = blocksWith(note, highlight.quote)[0];
      const section = highlight.chapter ?? NO_CHAPTER_SECTION;
      if (removed) {
        note.segments.splice(note.segments.indexOf(removed), 1);
        dropEmptyRemovedSection(note);
      }
      const kept = keptAndNew(removed?.block.note ?? "", highlight.note);
      const block = {
        blockId: removed?.block.blockId ?? newBlockId(highlight.quote),
        title: sharedTitle(removed?.block.title ?? titleOf(highlight.page, highlight.mark), highlight.shared === true),
        quote: normalizeNote(highlight.quote),
        note: kept,
        problem: highlight.problem,
        section,
        page: removed?.block.page ?? highlight.page,
        shared: highlight.shared === true
      };
      insertIntoSection(note, block, section, edit.laterChapters);
      return kept === normalizeNote(highlight.note);
    }
    case "problem": {
      for (const segment of blocksWith(note, edit.quote)) {
        segment.block.problem = edit.problem;
        rerender(segment);
      }
      return true;
    }
    case "giveIds": {
      for (const segment of note.segments) {
        if (segment.kind !== "block" || segment.block.section === REMOVED_SECTION) continue;
        if (segment.block.blockId === null && normalizeQuote(segment.block.quote) !== "") {
          segment.block.blockId = newBlockId(segment.block.quote);
          rerender(segment);
        }
      }
      return true;
    }
  }
}
function renderNote(note) {
  return note.segments.flatMap((segment) => segment.lines).join("\n");
}
function applyVaultEdits(text, edits) {
  if (edits.length === 0) return { text, differs: false };
  const note = parseNote(text);
  let differs = false;
  for (const edit of edits) {
    if (!applyEdit(note, edit)) differs = true;
  }
  return { text: renderNote(note), differs };
}
function setFrontmatter(text, fields) {
  const match = text.match(/^---\r?\n[\s\S]*?\r?\n---(?:\r?\n|$)/);
  if (!match) return text;
  let front = match[0];
  for (const [key, value] of Object.entries(fields)) {
    const line = new RegExp(`^${key}:.*$`, "m");
    front = line.test(front) ? front.replace(line, `${key}: ${value}`) : front.replace(/^---\r?\n/, (open) => `${open}${key}: ${value}
`);
  }
  return front + text.slice(match[0].length);
}
function renderFrontmatter(meta) {
  const lines = ["---", `vdh_book_id: ${meta.bookId}`];
  if (meta.base) lines.push(`vdh_base: ${meta.base}`);
  lines.push(`title: ${JSON.stringify(meta.title)}`);
  if (meta.author) lines.push(`author: ${JSON.stringify(meta.author)}`);
  lines.push("---", "");
  return lines.join("\n");
}
function safeFileName(title) {
  const name = title.replace(/[\\/:*?"<>|#^[\]]/g, " ").replace(/\s+/g, " ").trim().replace(/^\.+/, "");
  return name === "" ? "Untitled book" : name.slice(0, 180).trim();
}

// src/sync.ts
function emptyReport() {
  return {
    books: 0,
    notesCreated: 0,
    notesChanged: 0,
    highlightsAdded: 0,
    notesSent: 0,
    highlightsDeleted: 0,
    held: 0,
    skippedRecentlyEdited: [],
    errors: []
  };
}
function fingerprint(base, notes) {
  return hashText(JSON.stringify([base, notes]));
}
function basename(path) {
  return path.split("/").pop().replace(/\.md$/, "");
}
async function newNotePath(vault, folder, book) {
  const stem = `${folder ? `${folder}/` : ""}${safeFileName(book.title)}`;
  const path = `${stem}.md`;
  return await vault.exists(path) ? `${stem} (${book.id}).md` : path;
}
function editsFor(changes, sent, chapters) {
  const sentByQuote = new Map(sent.map((note) => [note.quote, note]));
  return changes.map((change) => {
    const known = sentByQuote.get(change.quote);
    if (known) {
      return change.removed ? { type: "moveToRemoved", quote: change.quote, expect: known.note } : {
        type: "setNote",
        quote: change.quote,
        note: change.note ?? "",
        problem: change.problem ?? null,
        shared: change.shared === true,
        expect: known.note
      };
    }
    const chapter = change.chapter ?? null;
    return {
      type: "add",
      highlight: {
        quote: change.quote,
        note: change.note ?? "",
        problem: change.problem ?? null,
        page: change.page ?? null,
        chapter,
        mark: change.mark ?? null,
        shared: change.shared === true
      },
      laterChapters: chapter === null ? [] : chapters.slice(chapters.indexOf(chapter) + 1)
    };
  });
}
function ownEdits(parsed) {
  if (!parsed) return [];
  const edits = [];
  for (const block of parsed.blocks) {
    if (normalizeQuote(block.quote) === "" && block.problem !== "no_quote") {
      edits.push({ type: "problem", quote: block.quote, problem: "no_quote" });
    }
  }
  if (parsed.blocks.some((b) => b.blockId === null && b.section !== REMOVED_SECTION)) {
    edits.push({ type: "giveIds" });
  }
  return edits;
}
async function syncBook(api, vault, entry, fingerprints, options, report, save) {
  const { book, path, noteId } = entry;
  const title = book?.title ?? basename(path);
  if (path && options.quietPeriodMs > 0) {
    const edited = await vault.modifiedAt(path);
    if (options.now().getTime() - edited < options.quietPeriodMs) {
      report.skippedRecentlyEdited.push(title);
      return;
    }
  }
  const text = path ? await vault.read(path) : null;
  const parsed = text === null ? null : parseNote(text);
  const notes = parsed ? notesOf(parsed) : [];
  const base = parsed?.base ?? null;
  const fingerprintKey = noteId ?? book.id;
  if (book && path && book.head === base && fingerprints[fingerprintKey] === fingerprint(base, notes)) {
    return;
  }
  const request = {
    book: {
      id: parsed?.bookId ?? book?.id ?? null,
      title: parsed?.title ?? book?.title ?? title,
      author: parsed?.author ?? book?.author ?? null
    },
    base,
    notes,
    dry: options.dryRun || !options.sendChanges
  };
  let reply = await api.sync(request);
  let declined = 0;
  if (reply.confirm !== void 0) {
    if (await options.confirmDeletes({ title }, reply.confirm)) {
      reply = await api.sync({ ...request, confirm: true });
    } else {
      declined = reply.confirm;
      reply = await api.sync({ ...request, dry: true });
    }
  }
  const changes = reply.changes ?? [];
  const sent = reply.sent ?? 0;
  const removed = reply.removed ?? 0;
  const added = changes.filter((change) => !change.removed && !notes.some((n) => n.quote === change.quote)).length;
  report.books++;
  report.highlightsAdded += added;
  const holding = !options.sendChanges || declined > 0;
  if (holding) report.held += sent + removed;
  else {
    report.notesSent += sent;
    report.highlightsDeleted += removed;
  }
  const edits = [...editsFor(changes, notes, reply.chapters ?? []), ...ownEdits(parsed)];
  if (options.dryRun) {
    if (text === null) {
      if (changes.length > 0) report.notesCreated++;
    } else if (edits.length > 0) report.notesChanged++;
    return;
  }
  const fields = { vdh_book_id: reply.book.id, ...reply.base ? { vdh_base: reply.base } : {} };
  let finalPath = path;
  if (text === null) {
    if (changes.length === 0) return;
    const front = renderFrontmatter({
      bookId: reply.book.id,
      base: reply.base ?? null,
      title: reply.book.title,
      author: reply.book.author
    });
    finalPath = await newNotePath(vault, options.folder, reply.book);
    await vault.create(finalPath, applyVaultEdits(front, edits).text);
    report.notesCreated++;
  } else if (path) {
    let touched = false;
    await vault.modify(path, (current) => {
      const { text: edited, differs } = applyVaultEdits(current, edits);
      touched = edited !== current;
      return setFrontmatter(edited, differs ? { vdh_book_id: reply.book.id } : fields);
    });
    if (touched) report.notesChanged++;
  }
  const after = parseNote(await vault.read(finalPath));
  if (holding && sent + removed > 0) delete fingerprints[reply.book.id];
  else fingerprints[reply.book.id] = fingerprint(after.base, notesOf(after));
  if (noteId && noteId !== reply.book.id) delete fingerprints[noteId];
  await save();
}
function recordFailure(report, title, error) {
  if (error instanceof NotLoggedInError) throw error;
  report.errors.push(`${title}: ${error instanceof Error ? error.message : String(error)}`);
}
async function syncAll(api, vault, fingerprints, options, save) {
  const report = emptyReport();
  const [books, notes] = await Promise.all([api.listBooks(), vault.bookNotes()]);
  const byId = new Map(books.map((book) => [book.id, book]));
  const entries = [];
  for (const [noteId, path] of notes) {
    entries.push({ book: byId.get(noteId), path, noteId });
  }
  for (const book of books) {
    if (book.passages > 0 && !notes.has(book.id)) {
      entries.push({ book, path: void 0, noteId: void 0 });
    }
  }
  for (const entry of entries) {
    try {
      await syncBook(api, vault, entry, fingerprints, options, report, save);
    } catch (error) {
      recordFailure(report, entry.book?.title ?? entry.path ?? "A book", error);
    }
  }
  return report;
}
function describeReport(report, dryRun) {
  const parts = [];
  const add = (count, text) => {
    if (count > 0) parts.push(`${count} ${text}`);
  };
  add(report.notesCreated, dryRun ? "book notes to create" : "book notes created");
  add(report.notesChanged, dryRun ? "book notes to change" : "book notes changed");
  add(report.highlightsAdded, dryRun ? "highlights to bring in" : "highlights brought in");
  add(report.notesSent, dryRun ? "highlights to send" : "highlights sent");
  add(report.highlightsDeleted, dryRun ? "highlights to delete" : "highlights deleted");
  add(report.held, "changes held back");
  add(report.skippedRecentlyEdited.length, "books waiting because you just edited them");
  add(report.errors.length, "errors");
  return parts.length > 0 ? parts.join(", ") : "Everything is in sync";
}
function hasNews(report) {
  return report.notesCreated + report.notesChanged + report.highlightsAdded + report.notesSent + report.highlightsDeleted > 0;
}
function statusLine(report, at) {
  const time = `${String(at.getHours()).padStart(2, "0")}:${String(at.getMinutes()).padStart(2, "0")}`;
  if (report.errors.length > 0) return `${report.errors.length} failed at ${time}, see the console`;
  if (report.skippedRecentlyEdited.length > 0) return "waiting for you to finish typing";
  return report.held > 0 ? `synced ${time}, ${report.held} changes held back` : `synced ${time}`;
}
function describeFailure(error) {
  if (error instanceof NotLoggedInError || error instanceof ApiError) return error.message;
  return "can't reach the server";
}

// src/main.ts
var DEFAULT_SETTINGS = {
  serverUrl: "",
  folder: "Books",
  intervalMinutes: 5,
  sendChanges: true,
  previewAccepted: false
};
var SECRET_ID = "vandenhove-device-token";
var QUIET_PERIOD_MS = 2 * 60 * 1e3;
var obsidianHttp = async (request) => {
  const response = await (0, import_obsidian.requestUrl)({
    url: request.url,
    method: request.method,
    headers: request.headers,
    ...request.body === void 0 ? {} : { body: request.body },
    throw: false
  });
  let json = null;
  try {
    json = JSON.parse(response.text);
  } catch {
  }
  return { status: response.status, json };
};
var ObsidianVault = class {
  constructor(app) {
    this.app = app;
  }
  app;
  async bookNotes() {
    const notes = /* @__PURE__ */ new Map();
    for (const file of this.app.vault.getMarkdownFiles()) {
      const cache = this.app.metadataCache.getFileCache(file);
      const id = cache ? cache.frontmatter?.["vdh_book_id"] : parseNote(await this.app.vault.cachedRead(file)).bookId;
      if ((typeof id === "number" || typeof id === "string") && !notes.has(String(id))) {
        notes.set(String(id), file.path);
      }
    }
    return notes;
  }
  file(path) {
    const file = this.app.vault.getAbstractFileByPath((0, import_obsidian.normalizePath)(path));
    if (!(file instanceof import_obsidian.TFile)) throw new Error(`${path} is not a note`);
    return file;
  }
  read(path) {
    return this.app.vault.read(this.file(path));
  }
  async modify(path, edit) {
    await this.app.vault.process(this.file(path), edit);
  }
  async create(path, text) {
    const normalized = (0, import_obsidian.normalizePath)(path);
    const folder = normalized.split("/").slice(0, -1).join("/");
    if (folder && !this.app.vault.getAbstractFileByPath(folder)) {
      await this.app.vault.createFolder(folder);
    }
    await this.app.vault.create(normalized, text);
  }
  async exists(path) {
    return this.app.vault.getAbstractFileByPath((0, import_obsidian.normalizePath)(path)) !== null;
  }
  async modifiedAt(path) {
    return this.file(path).stat.mtime;
  }
};
var ConfirmModal = class extends import_obsidian.Modal {
  constructor(app, heading, body, action, answer) {
    super(app);
    this.heading = heading;
    this.body = body;
    this.action = action;
    this.answer = answer;
  }
  heading;
  body;
  action;
  answer;
  answered = false;
  onOpen() {
    this.setTitle(this.heading);
    this.contentEl.createEl("p", { text: this.body });
    new import_obsidian.Setting(this.contentEl).addButton((button) => button.setButtonText("Not now").onClick(() => this.close())).addButton(
      (button) => button.setButtonText(this.action).setCta().onClick(() => {
        this.answered = true;
        this.close();
      })
    );
  }
  onClose() {
    this.contentEl.empty();
    this.answer(this.answered);
  }
};
var GroupNotesModal = class extends import_obsidian.Modal {
  constructor(app, title, notes) {
    super(app);
    this.title = title;
    this.notes = notes;
  }
  title;
  notes;
  onOpen() {
    this.setTitle(this.title);
    if (this.notes.length === 0) {
      this.contentEl.createEl("p", { text: "Nobody has shared anything from this book yet." });
      return;
    }
    let chapter;
    for (const note of this.notes) {
      if (note.chapter && note.chapter !== chapter) {
        chapter = note.chapter;
        this.contentEl.createEl("h4", { text: chapter });
      }
      this.contentEl.createEl("blockquote", { text: note.quote });
      if (note.note) this.contentEl.createEl("p", { text: note.note });
      this.contentEl.createEl("p", { text: `${note.name}, ${note.group}`, cls: "setting-item-description" });
    }
  }
  onClose() {
    this.contentEl.empty();
  }
};
var VandenHovePlugin = class extends import_obsidian.Plugin {
  settings = DEFAULT_SETTINGS;
  fingerprints = {};
  running = false;
  statusBar = null;
  /** The problem last shown, so a server that stays down is reported once, not every minute. */
  lastProblem = null;
  timer = null;
  api;
  async onload() {
    const data = await this.loadData() ?? {};
    this.settings = { ...DEFAULT_SETTINGS, ...data.settings };
    this.fingerprints = data.fingerprints ?? {};
    this.connect();
    this.addSettingTab(new VandenHoveSettingTab(this.app, this));
    this.statusBar = this.addStatusBarItem();
    this.addRibbonIcon("book-open", "Sync reading notes", () => void this.sync(true));
    this.addCommand({ id: "sync", name: "Sync now", callback: () => void this.sync(true) });
    this.addCommand({
      id: "preview",
      name: "Preview what a sync would do",
      callback: () => void this.preview()
    });
    this.addCommand({
      id: "share",
      name: "Share or unshare this passage with your groups",
      editorCallback: (editor) => {
        const edit = toggleShared(editor.getValue(), editor.getCursor().line);
        if (edit) editor.setLine(edit.line, edit.text);
        else new import_obsidian.Notice("Put the cursor in a passage first");
      }
    });
    this.addCommand({
      id: "group-notes",
      name: "Show your groups' notes on this book",
      callback: () => void this.showGroupNotes()
    });
    this.scheduleSync();
    this.app.workspace.onLayoutReady(() => void this.sync(false));
  }
  /** Obsidian's secret storage, kept out of the vault's own files. */
  tokenStore() {
    const secrets = this.app.secretStorage;
    return {
      get: () => secrets.getSecret(SECRET_ID) || null,
      set: (token) => secrets.setSecret(SECRET_ID, token ?? "")
    };
  }
  connect() {
    this.api = new ServerApi(this.settings.serverUrl, obsidianHttp, this.tokenStore());
  }
  async save() {
    await this.saveData({ settings: this.settings, fingerprints: this.fingerprints });
  }
  scheduleSync() {
    if (this.timer !== null) window.clearInterval(this.timer);
    this.timer = null;
    if (this.settings.intervalMinutes > 0) {
      this.timer = this.registerInterval(
        window.setInterval(() => void this.sync(false), this.settings.intervalMinutes * 60 * 1e3)
      );
    }
  }
  options(dryRun, manual) {
    return {
      folder: this.settings.folder.trim().replace(/^\/+|\/+$/g, ""),
      sendChanges: this.settings.sendChanges,
      dryRun,
      // Asking for a sync says the reader has finished typing.
      quietPeriodMs: manual ? 0 : QUIET_PERIOD_MS,
      now: () => /* @__PURE__ */ new Date(),
      confirmDeletes: (book, count) => this.confirmDeletes(book.title, count)
    };
  }
  confirmDeletes(title, count) {
    return new Promise(
      (resolve) => new ConfirmModal(
        this.app,
        "Delete these highlights?",
        `${count} highlights of "${title}" are gone from your note. Deleting them on the server removes them from your Kobo too. If the note was damaged, choose "Not now" and restore it.`,
        `Delete ${count} highlights`,
        resolve
      ).open()
    );
  }
  async run(dryRun, manual) {
    if (this.running) {
      if (manual) new import_obsidian.Notice("A vandenHove sync is already running");
      return null;
    }
    if (!this.api.isLoggedIn()) {
      if (manual) new import_obsidian.Notice("Connect vandenHove in the plugin's settings first");
      return null;
    }
    this.running = true;
    try {
      return await syncAll(
        this.api,
        new ObsidianVault(this.app),
        this.fingerprints,
        this.options(dryRun, manual),
        () => this.save()
      );
    } catch (error) {
      console.error("vandenHove:", error);
      this.showProblem(describeFailure(error), manual);
      return null;
    } finally {
      this.running = false;
    }
  }
  setStatus(text) {
    this.statusBar?.setText(`vandenHove: ${text}`);
  }
  showProblem(problem, manual) {
    this.setStatus(problem);
    if (manual || problem !== this.lastProblem) new import_obsidian.Notice(`vandenHove: ${problem}`);
    this.lastProblem = problem;
  }
  async sync(manual) {
    if (!this.settings.previewAccepted) {
      if (manual) await this.preview();
      return;
    }
    const report = await this.run(false, manual);
    if (!report) return;
    for (const error of report.errors) console.error("vandenHove:", error);
    this.setStatus(statusLine(report, /* @__PURE__ */ new Date()));
    const problem = report.errors[0] ?? null;
    const newProblem = problem !== null && problem !== this.lastProblem;
    if (manual || hasNews(report) || newProblem) {
      new import_obsidian.Notice(`vandenHove: ${describeReport(report, false)}`);
    }
    this.lastProblem = problem;
  }
  async showGroupNotes() {
    const file = this.app.workspace.getActiveFile();
    const note = file && parseNote(await this.app.vault.read(file));
    if (!note?.bookId) {
      new import_obsidian.Notice("Open a book's note first");
      return;
    }
    try {
      const notes = await this.api.groupNotes({ id: note.bookId, title: note.title, author: note.author });
      new GroupNotesModal(this.app, note.title ?? "Group notes", notes).open();
    } catch (error) {
      new import_obsidian.Notice(`vandenHove: ${describeFailure(error)}`);
    }
  }
  async preview() {
    const report = await this.run(true, true);
    if (!report) return;
    const summary = describeReport(report, true);
    const accepted = await new Promise(
      (resolve) => new ConfirmModal(this.app, "What a sync would do", summary, "Sync now", resolve).open()
    );
    if (!accepted) return;
    this.settings.previewAccepted = true;
    await this.save();
    await this.sync(true);
  }
};
var VandenHoveSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  plugin;
  code = "";
  display() {
    const { containerEl } = this;
    const { settings } = this.plugin;
    containerEl.empty();
    if (this.plugin.api.isLoggedIn()) {
      new import_obsidian.Setting(containerEl).setName("Connected").addButton(
        (button) => button.setButtonText("Code for another device").onClick(async () => {
          try {
            new import_obsidian.Notice(await this.plugin.api.newCode(), 6e4);
          } catch (error) {
            new import_obsidian.Notice(error instanceof Error ? error.message : String(error));
          }
        })
      ).addButton(
        (button) => button.setButtonText("Disconnect").onClick(() => {
          this.plugin.api.logout();
          this.display();
        })
      );
    } else {
      new import_obsidian.Setting(containerEl).setName("Code").addText(
        (text) => text.onChange((value) => {
          this.code = value;
        })
      ).addButton(
        (button) => button.setButtonText("Connect").setCta().onClick(async () => {
          try {
            await this.plugin.api.pair(this.code);
            this.code = "";
            this.display();
          } catch (error) {
            new import_obsidian.Notice(error instanceof Error ? error.message : String(error));
          }
        })
      );
    }
    new import_obsidian.Setting(containerEl).setName("Folder").setDesc("Where new book notes go. A note can be moved or renamed afterwards.").addText(
      (text) => text.setValue(settings.folder).onChange(async (value) => {
        settings.folder = value;
        await this.plugin.save();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Sync every (minutes)").setDesc("0 syncs only when you ask.").addText(
      (text) => text.setValue(String(settings.intervalMinutes)).onChange(async (value) => {
        const minutes = Number(value);
        if (!Number.isFinite(minutes) || minutes < 0) return;
        settings.intervalMinutes = minutes;
        this.plugin.scheduleSync();
        await this.plugin.save();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Send changes to the server").setDesc(
      "Off, your vault only receives. On, note edits, deletions and new highlights you make here reach your Kobo."
    ).addToggle(
      (toggle) => toggle.setValue(settings.sendChanges).onChange(async (value) => {
        settings.sendChanges = value;
        await this.plugin.save();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Preview").setDesc("See what a sync would do, without changing anything.").addButton((button) => button.setButtonText("Preview").onClick(() => void this.plugin.preview()));
  }
};
